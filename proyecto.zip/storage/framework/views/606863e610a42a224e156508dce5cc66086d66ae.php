<input type="checkbox" <?php echo $attributes->merge(['class' => 'form-check-input']); ?>>
<?php /**PATH G:\srv\laravel\IProyect\resources\views/components/checkbox.blade.php ENDPATH**/ ?>