<?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.userplantilla','data' => []]); ?>
<?php $component->withName('userplantilla'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('fonts'); ?> 

     <?php $__env->endSlot(); ?>
     <?php $__env->slot('styles'); ?> 
        <link href="<?php echo e(asset('css/green-audio-player.css')); ?>" rel="stylesheet" >
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css"/>
        <style>
            .green-audio-player{
                background-color: #0c171d;
            }
        </style>
     <?php $__env->endSlot(); ?>
     <?php $__env->slot('scriptsCDN'); ?> 
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
        <script src="<?php echo e(asset('js/green-audio-player.js')); ?>" defer></script>
     <?php $__env->endSlot(); ?>
     <?php $__env->slot('header'); ?> 
        <h2 class="font-semibold text-xl text-white leading-tight">
            <?php echo e(__('Playlist de '.$user->name)); ?>

        </h2>
     <?php $__env->endSlot(); ?>
     <?php $__env->slot('cuerpo'); ?> 
        <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.mensajes-alertas','data' => []]); ?>
<?php $component->withName('mensajes-alertas'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?> <?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
        <div class="w-100 animate__animated animate__fadeIn table-responsive-sm" id="cuerpo">
            <table class="table table-striped table-dark">
                <thead>
                    <tr>
                        <th scope="col">Nombre</th>
                        <th scope="col">Álbum</th>
                        <th scope="col">Autor</th>
                        <th scope="col">Play</th>
                        <th scope="col">Quitar</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $playlist; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($item->music->nombre); ?></td>
                            <td>
                                <a
                                    href="<?php echo e(route('verAlbum', ['album' => $item->music->album->id, 'nombre' => $item->music->album->nombre])); ?>"><?php echo e($item->music->album->nombre); ?></a>
                            </td>
                            <td><a
                                    href="<?php echo e(route('verAutor', ['autor' => $item->music->autor->id, 'nombre' => $item->music->autor->nombre])); ?>"><?php echo e($item->music->autor->nombre); ?></a>
                            </td>
                            <!-- Los audios cargan correctamente en apache y al usar php artisan serve en modo incognito -->
                            <td><div class="audioExample"><audio preload="auto" id='<?php echo e($item->music->id); ?>' onplay="parar(this.id)"
                                    onended="siguiente(this.id)">
                                    <source src="<?php echo e(asset($item->music->ruta)); ?>" type="audio/ogg">
                                    <source src="<?php echo e(asset($item->music->ruta)); ?>" type="audio/mp3">
                                    No lo soporta
                                </audio></div>
                            </td>
                            <td>
                                    <form method="POST" action="<?php echo e(route('playlists.destroy', $item)); ?>" name="a">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>
                                        <button type="submit" title="Borrar de tu playlist"><i class="fas fa-minus"></i></button>
                                    </form>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
        <?php echo e($playlist->links()); ?>

        <a href="<?php echo e(route('inicios.index')); ?>"><button class="btn btn-primary">Volver</button></a>

     <?php $__env->endSlot(); ?>
     <?php $__env->slot('script'); ?> 
        <script>
            document.addEventListener('DOMContentLoaded', function() {
                var audios = document.getElementsByClassName("audioExample");
                for (var i = 0; i<audios.length;i++){
                    new GreenAudioPlayer(audios[i], {
                        selector: '.player',
                        stopOthersOnPlay: true,
                    });
                }

                });

            function parar(idEl) {
                var elementos = document.getElementsByTagName('audio');
                for (var i = 0; i < elementos.length; i++) {
                    try {
                        if (elementos[i].id == idEl) {
                            var playPromise = elementos[i].play();
                            //Es necesario para que no salte error
                            playPromise.then(_ =>{

                            }).catch(error =>{

                            });

                        } else {
                            elementos[i].pause();
                        }
                    } catch (e) {
                        console.log("Error " + e)
                    }
                }
            }

            function siguiente(id) {
                id = parseInt(id);
                var elementos = document.getElementsByTagName('audio');
                for (var i = 0; i < elementos.length; i++) {
                    if (elementos[i].id == id) {
                        try {
                            if (elementos[i + 1] != null) {
                                elementos[i + 1].play();
                            } else {
                                console.log("Fin de la lista");
                            }
                        } catch (e) {
                            console.log("Error " + e)
                        }
                    } else {
                        elementos[i].pause();
                    }
                }
            }
        </script>
     <?php $__env->endSlot(); ?>

 <?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php /**PATH G:\srv\laravel\IProyect\resources\views/user/userplaylist.blade.php ENDPATH**/ ?>