<?php if (isset($component)) { $__componentOriginal01d89c16fe338d8b1dab1c1452c24963f0173285 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Adminplantilla::class, []); ?>
<?php $component->withName('adminplantilla'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('fonts'); ?> 

     <?php $__env->endSlot(); ?>
     <?php $__env->slot('styles'); ?> 
        <style>
            td a:link,
            :focus,
            :active {
                text-decoration: none;
                color: white;
            }

            td a:visited {
                text-decoration: none;
                color: white;
            }

            td a:hover {
                color: lightblue;
            }

            /* Specifies the size of the audio container */
            audio {
                width: 115px;
                height: 25px;
            }

            audio::-webkit-media-controls-panel {
                -webkit-justify-content: center;
                height: 25px;
            }

            /* Removes the timeline */
            audio::-webkit-media-controls-timeline {
                display: none !important;
            }

            /* Removes the time stamp */
            audio::-webkit-media-controls-current-time-display {
                display: none;
            }

            audio::-webkit-media-controls-time-remaining-display {
                display: none;
            }

            .dataTables_wrapper {
                color: white;
            }


            .select2-search input {
                background-color: #212E36;
                color: #C8CDD0;
            }

            .select2-search {
                background-color: #212E36;
            }

            .select2-selection__rendered {
                background-color: #ffffff;
                color: #C8CDD0;
            }

        </style>
     <?php $__env->endSlot(); ?>
     <?php $__env->slot('scriptsCDN'); ?> 
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css" />

     <?php $__env->endSlot(); ?>
     <?php $__env->slot('header'); ?> 
        <h2 class="font-semibold text-xl text-white leading-tight">
            <?php echo e(__('Modificación de tablas')); ?>

        </h2>
     <?php $__env->endSlot(); ?>
     <?php $__env->slot('cuerpo'); ?> 
        <button class="btn btn-dark" onclick="cambio('album')">Album</button>
        <button class="btn btn-dark" onclick="cambio('autor')">Autor</button>
        <button class="btn btn-dark" onclick="cambio('music')">Música</button>
        <button class="btn btn-dark" onclick="cambio('genero')">Género</button>
        <button class="btn btn-dark" onclick="cambio('user')">Usuario</button>
        <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.mensajes-alertas','data' => []]); ?>
<?php $component->withName('mensajes-alertas'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?> <?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
        <div class="w-100 " id="cuerpo">
        </div>
        <a href="<?php echo e(route('inicios.index')); ?>"><button class="btn btn-dark">Volver</button></a>
     <?php $__env->endSlot(); ?>
     <?php $__env->slot('script'); ?> 
        <script>
            window.onload = function() {
                var tabla = parametroTabla();
                $('#cuerpo').load(`${tabla}`);
            };

            //Botones de cambio de tabla
            function cambio(tabla) {
                var link = ruta(tabla);
                console.log(link);
                $('#cuerpo').load(`${link}`);
            }

            //Al realizar alguna acción del crud, regresar a la tabla en la que te encontrabas.
            function parametroTabla() {
                var queryString = window.location.search;
                var urlParams = new URLSearchParams(queryString);
                var tabla = urlParams.get('tabla');
                if (tabla == null) {
                    tabla = "<?php echo e(route('adminAlbum')); ?>";
                } else {
                    return ruta(tabla);
                }
            }

            //switch con las rutas donde tienes que ir
            function ruta(tabla) {
                switch (tabla) {
                    case "album":
                        return link = "<?php echo e(route('adminAlbum')); ?>";
                        break;
                    case "autor":
                        return link = "<?php echo e(route('adminAutor')); ?>";
                        break;
                    case "music":
                        return link = "<?php echo e(route('adminMusic')); ?>";
                        break;
                    case "genero":
                        return link = "<?php echo e(route('adminGenero')); ?>";
                        break;
                    case "user":
                        return link = "<?php echo e(route('adminUser')); ?>";
                        break;
                    default:
                        return link = "<?php echo e(route('adminAlbum')); ?>";
                        break;
                }
            }

        </script>
     <?php $__env->endSlot(); ?>
 <?php if (isset($__componentOriginal01d89c16fe338d8b1dab1c1452c24963f0173285)): ?>
<?php $component = $__componentOriginal01d89c16fe338d8b1dab1c1452c24963f0173285; ?>
<?php unset($__componentOriginal01d89c16fe338d8b1dab1c1452c24963f0173285); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php /**PATH G:\srv\laravel\IProyect\resources\views/administrador/adminindex.blade.php ENDPATH**/ ?>