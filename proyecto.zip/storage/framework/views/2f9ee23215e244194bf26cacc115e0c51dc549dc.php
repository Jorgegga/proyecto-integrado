<?php $playMusic = app('App\Models\Playlist'); ?>
<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('fonts'); ?> 
     <?php $__env->endSlot(); ?>
     <?php $__env->slot('styles'); ?> 
        <link href="<?php echo e(asset('css/green-audio-player.css')); ?>" rel="stylesheet">
        <link rel="stylesheet" href="https://cdn.datatables.net/1.10.24/css/dataTables.bootstrap4.min.css">
        <style>
            .green-audio-player {
                background-color: #0c171d;
            }

            .dataTables_wrapper {
                color: white;
            }

        </style>
     <?php $__env->endSlot(); ?>
     <?php $__env->slot('scriptsCDN'); ?> 
        <script src="<?php echo e(asset('js/green-audio-player.js')); ?>" defer></script>
     <?php $__env->endSlot(); ?>
     <?php $__env->slot('header'); ?> 
        <h2 class="font-semibold text-xl text-white leading-tight">
            <?php echo e(__('Música')); ?>

        </h2>
     <?php $__env->endSlot(); ?>
     <?php $__env->slot('cuerpo'); ?> 
        <div class="py-12 animate__animated animate__fadeInDown">
            <div class="max-w-7xl mx-auto sm:px-6 lg:px-8 mb-4">
                <div class="overflow-hidden shadow-sm rounded pt-2" style="background-color:#212E36;">
                    <div class="p-6 border-b border-gray-200 text-center">
                        <h4 style="color: #EFF3F5">Toda nuestra base de datos de música</h4>
                        <p style="color: #C8CDD0">Aquí la encontrarás</p>
                    </div>
                </div>
            </div>
        </div>
        <section
            class="row justify-content-center mt-md-4 mb-md-4 mt-sm-4 mb-sm-4 animate__animated animate__fadeIn animate__slow">
            <!--<div class="col-10 pr-3">-->
            <div class="table-responsive">
                <table class="table table-striped table-dark" id="tabla">
                    <thead>
                        <tr>
                            <th scope="col">Nombre</th>
                            <th scope="col">Álbum</th>
                            <th scope="col">Autor</th>
                            <th scope="col">Género</th>
                            <th scope="col">Play</th>
                            <?php if(auth()->guard()->check()): ?>
                                <th scope="col">Añadir</th>
                            <?php endif; ?>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $musica; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($item->nombre); ?></td>
                                <td>
                                    <a
                                        href="<?php echo e(route('verAlbum', ['album' => $item->album->id, 'nombre' => $item->album->nombre])); ?>"><?php echo e($item->album->nombre); ?></a>
                                </td>
                                <td><a
                                        href="<?php echo e(route('verAutor', ['autor' => $item->autor->id, 'nombre' => $item->autor->nombre])); ?>"><?php echo e($item->autor->nombre); ?></a>
                                </td>
                                <td><?php echo e(ucfirst($item->genero->nombre)); ?></td>
                                <!-- Los audios cargan correctamente en apache y al usar php artisan serve en modo incognito -->
                                <td>
                                    <div class="audioExample"><audio preload="none" id='<?php echo e($item->id); ?>'
                                            onplay="parar(this.id)" onended="siguiente(this.id)">
                                            <source src="<?php echo e(asset($item->ruta)); ?>" type="audio/ogg">
                                            <source src="<?php echo e(asset($item->ruta)); ?>" type="audio/mp3">
                                            No lo soporta
                                        </audio></div>
                                </td>
                                <?php if(auth()->guard()->check()): ?>
                                    <td>
                                        <?php if($playMusic->musicExist(Auth::user(), $item->id) == 0): ?>
                                            <form method="POST"
                                                action="<?php echo e(route('playlists.store', ['user' => Auth::user()->id, 'music' => $item->id])); ?>"
                                                id="anadirPlaylist<?php echo e($item->id); ?>"
                                                onsubmit="submitForm(event, <?php echo e($item->id); ?>)">
                                                <?php echo csrf_field(); ?>
                                                <button id="btn<?php echo e($item->id); ?>" type="submit"
                                                    title="Añadir a tu playlist"><i class="fas fa-plus"></i></button>
                                            </form>
                                        <?php else: ?>
                                            <button type="submit" title="Ya esta en tu playlist" disabled><i
                                                    class="fas fa-plus"></i></button>
                                        <?php endif; ?>
                                    </td>
                                <?php endif; ?>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>

            <!--</div>-->
        </section>

     <?php $__env->endSlot(); ?>
     <?php $__env->slot('script'); ?> 
        <script>
            $(document).ready(function() {
                $('#tabla').DataTable();
            });

/*
            $(document).ready(function(){
                $('#tabla').DataTable({
                    "processing": true,
                    "serverSide": true,
                    "ajax":{
                        url:"<?php echo e(url('api/musics')); ?>",

                        dataType: 'json',
                        contentType: 'application/json; charset=utf-8',
                    },
                    "columns": [
                        {data: 'nombre', },
                        {data: 'album_id', },
                        {data: 'autor_id', },
                        {data: 'genero_id', },
                        {data: 'ruta',},
                        {data: 'añadir'}
                    ]
                });
            });*/

            document.addEventListener('DOMContentLoaded', function() {
                var audios = document.getElementsByClassName("audioExample");
                for (var i = 0; i < audios.length; i++) {
                    new GreenAudioPlayer(audios[i], {
                        selector: '.player',
                        stopOthersOnPlay: true,
                    });
                }

            });

            function parar(idEl) {
                var elementos = document.getElementsByTagName('audio');
                for (var i = 0; i < elementos.length; i++) {
                    try {
                        if (elementos[i].id == idEl) {
                            var playPromise = elementos[i].play();
                            //Es necesario para que no salte error
                            playPromise.then(_ => {

                            }).catch(error => {

                            });

                        } else {
                            elementos[i].pause();
                        }
                    } catch (e) {
                        console.log("Error " + e)
                    }
                }
            }

            function siguiente(id) {
                id = parseInt(id);
                var elementos = document.getElementsByTagName('audio');
                for (var i = 0; i < elementos.length; i++) {
                    if (elementos[i].id == id) {
                        try {
                            if (elementos[i + 1] != null) {
                                elementos[i + 1].play();
                            } else {
                                console.log("Fin de la lista");
                            }
                        } catch (e) {
                            console.log("Error " + e)
                        }
                    } else {
                        elementos[i].pause();
                    }
                }
            }

            function submitForm(event, id) {
                boton = "btn" + id;
                id = "#anadirPlaylist" + id;
                $.ajax({
                    type: $(id).attr('method'),
                    url: $(id).attr('action'),
                    data: $(id).serialize(),
                    success: function(data) {
                        console.log('Datos enviados !!!');
                        document.getElementById(boton).disabled = true;
                        document.getElementById(boton).title = "Ya esta en tu playlist";
                    }
                });
                event.preventDefault();
            }

        </script>
     <?php $__env->endSlot(); ?>
 <?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php /**PATH G:\srv\laravel\proyect\IProyect\resources\views/musica/musicaindex.blade.php ENDPATH**/ ?>