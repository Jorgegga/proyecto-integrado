<?php $__currentLoopData = $autor; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="card mb-5 w-100" style="background-color:#212E36;">
                    <img src='<?php echo e(asset($item->foto)); ?>'
                        class="card-img-top"/>
                    <div class="card-body">
                        <h5 class="card-title" style="font-size:1.75em; text-align: left; color: #EFF3F5">
                            <?php echo e($item->nombre); ?></h5>
                        <p class="card-text" style="font-size:0.9em; color: #C8CDD0">
                            <?php echo e($item->descripcion); ?>

                        </p>
                        <a href="<?php echo e(route('verAutor', ['autor' => $item, 'nombre'=> $item->nombre])); ?>" class="btn btn-primary">Obras del autor</a>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php /**PATH G:\srv\laravel\IProyect\resources\views/autor/pagination.blade.php ENDPATH**/ ?>