<?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.userplantilla','data' => []]); ?>
<?php $component->withName('userplantilla'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('fonts'); ?> 

     <?php $__env->endSlot(); ?>
     <?php $__env->slot('styles'); ?> 
        <style>
            .card {
                flex-direction: row;
                align-items: center;
            }

            .card-title {
                font-weight: bold;
            }

            .card img {
                width: 30%;
                border-top-right-radius: 0;
                border-bottom-left-radius: calc(0.25rem - 1px);
            }

            @media  only screen and (max-width: 768px) {
                a {
                    display: none;
                }

                .card-body {
                    padding: 0.5em 1.2em;
                }

                .card-body .card-text {
                    margin: 0;
                }

                .card img {
                    width: 50%;
                }
            }

            @media  only screen and (max-width: 1200px) {
                .card img {
                    width: 40%;
                }
            }

            .inputOscuro {
                background-color: #212E36;
                color: #C8CDD0;
                font-size: 20px;
            }

            .cabeceraOscura {
                color: #EFF3F5;
            }

            .image-upload>input {
                display: none;
            }

        </style>
     <?php $__env->endSlot(); ?>
     <?php $__env->slot('scriptsCDN'); ?> 
     <?php $__env->endSlot(); ?>
     <?php $__env->slot('header'); ?> 
        <h2 class="font-semibold text-xl text-white leading-tight">
            <?php echo e(__('Área de ' . $user->name)); ?>

        </h2>
     <?php $__env->endSlot(); ?>
     <?php $__env->slot('cuerpo'); ?> 
        <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.mensajes-alertas','data' => []]); ?>
<?php $component->withName('mensajes-alertas'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?> <?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
        <section
            class="row justify-content-center mt-md-4 mb-md-4 mt-sm-4 mb-sm-4 animate__animated animate__fadeInLeft"
            id="autores">
            <!--<div class="col-10 pr-3">-->
                <form name="a" action="<?php echo e(route('updateUser', Auth::user()->id)); ?>" method="POST"
                    enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('PUT'); ?>
            <div class="card mb-5 w-100" style="background-color:#212E36;">
                <img src='<?php echo e(asset($user->foto)); ?>' class="card-img-top pl-4" />
                <div class="card-body">
                    <div clas="row">
                        <form name="a" action="" method="POST" enctype="multipart/form-data">
                        <h3 class="cabeceraOscura">Usuario</h3>
                        <input id="inputNombre" name="inputNombre" class="inputOscuro" type="text"
                            value="<?php echo e($user->name); ?>"><br><br>
                    </div>
                    <div clas="row">
                        <h3 class="cabeceraOscura">Contraseña</h3>
                        <input type="password" id="inputPass" name="inputPass" class="inputOscuro" type="text" value=""><br><br>
                    </div>
                    <div clas="row">
                        <h3 class="cabeceraOscura">Correo</h3>
                        <input id="inputEmail" name="inputEmail" class="inputOscuro" type="text"
                            value="<?php echo e($user->email); ?>"><br><br>
                    </div>
                    <div class="row">
                        <h3 class="cabeceraOscura ml-3">Subir foto de perfil</h3>
                        <input class="form-control-file ml-3" type="file" accept="image/png, image/jpeg" name="foto" style="color:white">
                    </div>
                    <button id="boton" type="submit" class="btn btn-primary float-right"  >Guardar cambios</button>
                </div>
            </div>

            <!--</div>-->
                </form>
        </section>
     <?php $__env->endSlot(); ?>
     <?php $__env->slot('script'); ?> 

     <?php $__env->endSlot(); ?>

 <?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php /**PATH G:\srv\laravel\IProyect\resources\views/user/userinicio.blade.php ENDPATH**/ ?>