<img src='<?php echo e(asset($album->portada)); ?>' class="mx-auto d-block img-fluid w-50 mb-3" height="50px">

<h5 style="color: #EFF3F5;">Id</h5>
<p class=" border-0 rounded p-2" style="background-color:#212E36; color: #C8CDD0;">
    <?php echo e($album->id); ?></p>

<h5 style="color: #EFF3F5;">Nombre</h5>
<p class=" border-0 rounded p-2" style="background-color:#212E36; color: #C8CDD0;">
    <?php echo e($album->nombre); ?></p>


<h5 style="color: #EFF3F5;">Descripcion</h5>
<p class="border-0 rounded p-2" style="background-color:#212E36; color: #C8CDD0;">
    <?php echo e($album->descripcion); ?></p>


<h5 style="color: #EFF3F5;">Autor</h5>
<p class="border-0 rounded p-2" style="background-color:#212E36; color: #C8CDD0;">
    <?php echo e($album->autor->nombre); ?>

</p>


<h5 style="color: #EFF3F5;">Género</h5>
<p class="border-0 rounded p-2" style="background-color:#212E36; color: #C8CDD0;">
    <?php echo e(ucfirst($album->genero->nombre)); ?>

</p>


<h5 style="color: #EFF3F5;">Nº de temas</h5>
<p class="border-0 rounded p-2" style="background-color:#212E36; color: #C8CDD0;">
    <?php echo e($album->music->count('id')); ?>

</p>


<h5 style="color: #EFF3F5;">Fecha de creación</h5>
<p class="border-0 rounded p-2" style="background-color:#212E36; color: #C8CDD0;">
    <?php echo e($album->created_at); ?>

</p>


<h5 style="color: #EFF3F5;">Fecha de actualización</h5>
<p class="border-0 rounded p-2" style="background-color:#212E36; color: #C8CDD0;">
    <?php echo e($album->updated_at); ?>

</p>
<?php /**PATH G:\srv\laravel\IProyect\resources\views/administrador/raw/albumrawdetalles.blade.php ENDPATH**/ ?>