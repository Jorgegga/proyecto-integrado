<img src='<?php echo e(asset($autor->foto)); ?>' class="mx-auto d-block img-fluid w-50 mb-3" height="50px">

<h5 style="color: #EFF3F5;">Id</h5>
<p class="border-0 rounded p-2" style="background-color:#212E36; color: #C8CDD0;">
    <?php echo e($autor->id); ?></p>

<h5 style="color: #EFF3F5;">Nombre</h5>
<p class="border-0 rounded p-2" style="background-color:#212E36; color: #C8CDD0;">
    <?php echo e($autor->nombre); ?></p>

<h5 style="color: #EFF3F5;">Descripcion</h5>
<p class="border-0 rounded p-2" style="background-color:#212E36; color: #C8CDD0;">
    <?php echo e($autor->descripcion); ?></p>
<h5 style="color: #EFF3F5;">Género</h5>
<p class="border-0 rounded p-2" style="background-color:#212E36; color: #C8CDD0;">
    <?php echo e(ucfirst($autor->genero->nombre)); ?>

</p>
<h5 style="color: #EFF3F5;">Fecha de creación</h5>
<p class="border-0 rounded p-2" style="background-color:#212E36; color: #C8CDD0;">
    <?php echo e($autor->created_at); ?>

</p>
<h5 style="color: #EFF3F5;">Fecha de actualización</h5>
<p class="border-0 rounded p-2" style="background-color:#212E36; color: #C8CDD0;">
    <?php echo e($autor->updated_at); ?>

</p>
<?php /**PATH G:\srv\laravel\IProyect\resources\views/administrador/raw/autorrawdetalles.blade.php ENDPATH**/ ?>