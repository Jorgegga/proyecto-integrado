[<?php echo e($slot); ?>](<?php echo e($url); ?>)
<?php /**PATH G:\srv\laravel\IProyect\resources\views/vendor/mail/text/header.blade.php ENDPATH**/ ?>