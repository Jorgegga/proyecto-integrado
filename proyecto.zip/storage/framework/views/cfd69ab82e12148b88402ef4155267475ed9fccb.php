<button <?php echo e($attributes->merge(['type' => 'submit', 'class' => 'btn btn-dark'])); ?>>
    <?php echo e($slot); ?>

</button>
<?php /**PATH G:\srv\laravel\IProyect\resources\views/components/button.blade.php ENDPATH**/ ?>