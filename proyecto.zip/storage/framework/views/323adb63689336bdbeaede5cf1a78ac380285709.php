<?php $playMusic = app('App\Models\Playlist'); ?>
<section class="row justify-content-center mt-md-4 mb-md-4 mt-sm-4 mb-sm-4">
    <!--<div class="col-10 pr-3">-->
    <div class="card mb-2" style="background-color:#212E36; width:90%;">
        <img src='<?php echo e(asset($album->portada)); ?>' class="card-img-top" />
        <div class="card-body">
            <h5 class="card-title" style="font-size:1.75vw; text-align: left; color: #EFF3F5" id="cabeceraCard">
                Selecciona una canción</h5>
            <p class="card-text" style="font-size:0.9vw; color: #C8CDD0" id="cuerpoCard"></p>
            <div class="audioExample">
                <audio preload="auto" name="audio" onplay="parar(this.id)" onended="siguiente(this.id)"
                    style="color: black" crossorigin>
                    <source src="" id="oggAudio" type="audio/ogg">
                    <source src="" id="mp3Audio" type="audio/mp3">
                    No lo soporta
                </audio>
            </div>
        </div>
    </div>
    <!--</div>-->
</section>
<table class="table table-sm table-dark table-responsive-sm">
    <thead>
        <tr>
            <th scope="col">Nombre</th>
            <th scope="col">Pista</th>
            <th scope="col">Play</th>
            <?php if(auth()->guard()->check()): ?>
            <th scope="col">Añadir</th>
            <?php endif; ?>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $music; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($item->nombre); ?></td>
                <td><?php echo e($item->numCancion); ?></td>
                <td>
                    <button class="circle" name="botonsito" id="<?php echo e($item->id); ?>"
                        onclick="cabecera( '<?php echo e($item->nombre); ?>', '<?php echo e($item->ruta); ?>', '<?php echo e($item->id); ?>', '<?php echo e($item->autor->nombre); ?>')"><i
                            class="fas fa-play-circle"></i></button>
                </td>
                <?php if(auth()->guard()->check()): ?>
                    <td>
                        <?php if($playMusic->musicExist(Auth::user(), $item->id) == 0): ?>
                            <form method="POST"
                                action="<?php echo e(route('playlists.store', ['user' => Auth::user()->id, 'music' => $item->id])); ?>"
                                id="anadirPlaylist<?php echo e($item->id); ?>" onsubmit="submitForm(event, <?php echo e($item->id); ?>)">
                                <?php echo csrf_field(); ?>
                                <button id="btn<?php echo e($item->id); ?>" type="submit" title="Añadir a tu playlist"><i
                                        class="fas fa-plus"></i></button>
                            </form>
                        <?php else: ?>
                            <button type="submit" title="Ya esta en tu playlist" disabled><i
                                    class="fas fa-plus"></i></button>
                        <?php endif; ?>
                    </td>
                <?php endif; ?>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>
<?php /**PATH G:\srv\laravel\IProyect\resources\views/album/albumraw.blade.php ENDPATH**/ ?>