<?php echo e($slot); ?>

<?php /**PATH G:\srv\laravel\IProyect\resources\views/vendor/mail/text/subcopy.blade.php ENDPATH**/ ?>