<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title><?php echo e(config('app.name', 'Laravel')); ?></title>

    <!-- Fonts -->
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Nunito:wght@400;600;700&display=swap">
    <link href="https://fonts.googleapis.com/css2?family=Knewave&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Just+Another+Hand&display=swap" rel="stylesheet">
    <link rel="preconnect" href="https://fonts.gstatic.com">
    <?php echo e($fonts); ?>



    <!-- Styles -->
    <link rel="stylesheet" href="<?php echo e(asset('css/app.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/estilos.css')); ?>" />
    <?php echo e($styles); ?>


    <!-- Scripts -->
    <script src="<?php echo e(asset('js/app.js')); ?>" ></script>
    <script src="https://code.jquery.com/jquery-3.5.1.js" ></script>
    <link href="https://cdn.jsdelivr.net/npm/select2@4.1.0-beta.1/dist/css/select2.min.css" rel="stylesheet" />
    <script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-beta.1/dist/js/select2.min.js"></script>
    <?php echo e($scriptsCDN); ?>



</head>

<body class="font-sans antialiased" style="background-color: #192229">
    <?php echo $__env->make('layouts.navigation', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- Page Heading -->
    <header class="d-flex py-3 shadow-sm border-bottom border-secondary col-12">
        <div class="container">
            <?php echo e($header); ?>

        </div>
    </header>

    <!-- Page Content -->
    <main class="container my-5">
        <?php echo e($cuerpo); ?>

    </main>

    <?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <script>
        //Posiciona el footer en la parte de abajo a pesar de que la pantalla sea pequeña

        $(document).ready(function() {
            if ($("body").height() > $(window).height()) {
                $("footer").css({
                    "position": "absolute",
                    "bottom": "0px"
                });
            }
        });

        //En caso de cambiar el tamaño de la ventana, ya sea porque la pasamos a otro monitor u otro motivo
        //esto hara que permanezca abajo
        window.onresize = function(event) {
            if ($("body").height() < $(window).height()) {
                $("footer").css({
                    "position": "absolute",
                    "bottom": "0px"
                });
            }
        }


    </script>
            <script src="https://cdn.datatables.net/1.10.24/js/jquery.dataTables.min.js"></script>
            <script src="https://cdn.datatables.net/1.10.24/js/dataTables.bootstrap4.min.js"></script>

    <?php echo e($script); ?>


</body>

</html>
<?php /**PATH G:\srv\laravel\IProyect\resources\views/components/adminplantilla.blade.php ENDPATH**/ ?>