<footer class="container-fluid mt-5">
    <div class="row justify-content-center" style="background-color: #0f2738;color: #EFF3F5" align="center">
        <div class="col-6">
        <p>Esta página ha sido realizada por Jorge Gonzalo Galindo Almena</p>
        <a rel="license" href="http://creativecommons.org/licenses/by/4.0/"><img alt="Licencia de Creative Commons"
                style="border-width:0" src="https://i.creativecommons.org/l/by/4.0/88x31.png" /></a><br />Este obra está
        bajo una <a rel="license" href="http://creativecommons.org/licenses/by/4.0/">licencia de Creative Commons
            Reconocimiento 4.0 Internacional</a>.
        </div>
    </div>
</footer>
<?php /**PATH G:\srv\laravel\proyect\IProyect\resources\views/layouts/footer.blade.php ENDPATH**/ ?>