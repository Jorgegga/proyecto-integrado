<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('fonts'); ?> 
        <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Trirong:300,400,400i,500,600,700" />
     <?php $__env->endSlot(); ?>
     <?php $__env->slot('styles'); ?> 
        <link href="<?php echo e(asset('css/resCarousel.css')); ?>" rel="stylesheet" type="text/css">
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.6.3/css/font-awesome.min.css"/>
     <?php $__env->endSlot(); ?>
     <?php $__env->slot('scriptsCDN'); ?> 
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
     <?php $__env->endSlot(); ?>
     <?php $__env->slot('header'); ?> 

        <h2 class="font-semibold text-xl text-white leading-tight titulo-align">
            <?php echo e(__('Inicio')); ?>

        </h2>

     <?php $__env->endSlot(); ?>
     <?php $__env->slot('cuerpo'); ?> 
        <div class="py-12 animate__animated animate__fadeInDown">
            <div class="max-w-7xl mx-auto sm:px-6 lg:px-8 mb-4">
                <div class="overflow-hidden shadow-sm rounded pt-2 fondo-gris">
                    <div class="p-6 border-b border-gray-200 text-center">
                        <h4 class="titulo">¡Bienvenido a la página principal!</h4>
                        <p class="parrafo">Aquí encontraras los últimos álbums que hemos añadido a nuestro repertorio junto con alguna cosilla más, ¡disfrutalos!</p>
                    </div>
                </div>
            </div>
        </div>
        <h3 class="font-semibold text-xl text-white leading-tight text-center animate__animated animate__fadeIn mb-3">
            Últimos álbums añadidos
        </h3>
        <!--A este paquete de animaciones al parecer no le gusta el carousel de bootstrap y si pones una animacion desde los lados
        la pagina recibe una embolia y todos los elementos de la pagina reciben animaciones raras-->
        <div id="ultimosAlbum" class="carousel slide border-bottom border-secondary pb-3 animate__animated animate__fadeIn"  data-ride="carousel">
            <ol class="carousel-indicators">
                <?php $__currentLoopData = $albumNew; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li data-target="#ultimosAlbum" data-slide-to="<?php echo e($loop->index); ?>"
                        class="<?php echo e($loop->first ? 'active' : ''); ?>"></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ol>
            <div class="carousel-inner">
                <?php $__currentLoopData = $albumNew; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="carousel-item <?php echo e($loop->first ? 'active' : ''); ?>"  title="<?php echo e($item->nombre); ?>">
                        <a href="<?php echo e(route('verAlbum', ['album' => $item, 'nombre'=> $item->nombre])); ?>">
                            <img src="<?php echo e(asset($item->portada)); ?>" class="img-responsive d-block m-auto img-peque">
                        </a>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <a class="carousel-control-prev" href="#ultimosAlbum" role="button" data-slide="prev">
                <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                <span class="sr-only">Previous</span>
            </a>
            <a class="carousel-control-next" href="#ultimosAlbum" role="button" data-slide="next">
                <span class="carousel-control-next-icon" aria-hidden="true"></span>
                <span class="sr-only">Next</span>
            </a>
        </div>

        <div class="container p8 mt-4 animate__animated animate__fadeInUp">
            <h3 class="font-semibold text-xl text-white leading-tight text-center">
                Últimos autores añadidos
            </h3>
            <div class="resCarousel" data-items="2-4-4-4" data-interval="2000" data-slide="2" data-animator="lazy">
                <div class="resCarousel-inner">
                    <?php $__currentLoopData = $autorNew; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <a href="<?php echo e(route('verAutor', ['autor' => $item, 'nombre'=> $item->nombre])); ?>">
                    <div class="item" title="<?php echo e($item->nombre); ?>">
                        <div class="tile">
                            <img src="<?php echo e(asset($item->foto)); ?>" class="carousel2img img-responsive ">
                        </div>
                    </div>
                </a>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </div>
                <button class='btn btn-light leftRs' style="opacity: 0.4"><</button>
                <button class='btn btn-light rightRs' style="opacity: 0.4">></button>
            </div>
        </div>

     <?php $__env->endSlot(); ?>
     <?php $__env->slot('script'); ?> 
        <script src="<?php echo e(asset('js/dashboard.js')); ?>"></script>
        <script src="<?php echo e(asset('js/resCarousel.js')); ?>"></script>
     <?php $__env->endSlot(); ?>
 <?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php /**PATH G:\srv\laravel\proyect\IProyect\resources\views/dashboard.blade.php ENDPATH**/ ?>