<img src='<?php echo e(asset($user->foto)); ?>' class="mx-auto d-block img-fluid w-50 mb-3" height="50px">

<h5 style="color: #EFF3F5;">Id</h5>
<p class="border-0 rounded p-2" style="background-color:#212E36; color: #C8CDD0;">
    <?php echo e($user->id); ?></p>

<h5 style="color: #EFF3F5;">Nombre</h5>
<p class="border-0 rounded p-2" style="background-color:#212E36; color: #C8CDD0;">
    <?php echo e($user->name); ?></p>


<h5 style="color: #EFF3F5;">Email</h5>
<p class="border-0 rounded p-2" style="background-color:#212E36; color: #C8CDD0;">
    <?php echo e($user->email); ?>

</p>


<h5 style="color: #EFF3F5;">Permisos</h5>
<p class="border-0 rounded p-2" style="background-color:#212E36; color: #C8CDD0;">
    <?php if($user->permisos == 0): ?>
        Administrador
    <?php else: ?>
        Usuario
    <?php endif; ?>
</p>


<h5 style="color: #EFF3F5;">Fecha de creación</h5>
<p class="border-0 rounded p-2" style="background-color:#212E36; color: #C8CDD0;">
    <?php echo e($user->created_at); ?>

</p>


<h5 style="color: #EFF3F5;">Fecha de actualización</h5>
<p class="border-0 rounded p-2" style="background-color:#212E36; color: #C8CDD0;">
    <?php echo e($user->updated_at); ?>

</p>
<?php /**PATH G:\srv\laravel\IProyect\resources\views/administrador/raw/userrawdetalles.blade.php ENDPATH**/ ?>