<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Mensaje nuevo</title>
</head>
<body>
    <p>Nuevo mensaje de: <?php echo e($mensaje['correo']); ?></p>
    <p>Asunto: <strong>Añadir album/canción</strong></p>
    <p>Elemento: <strong><?php echo e($mensaje['options']); ?></strong> </p>
    <p>Titulo: <strong><?php echo e($mensaje['titulo']); ?></strong></p>
    <p>Autor: <strong><?php echo e($mensaje['autor']); ?></strong></p>
</body>
</html>
<?php /**PATH G:\srv\laravel\IProyect\resources\views/email/formulario-add.blade.php ENDPATH**/ ?>