<tr>
<td class="header">
<a href="<?php echo e(route('inicios.index')); ?>" height="50" width="200">
<?php if(trim($slot) === 'Laravel'): ?>
<img src="https://i.postimg.cc/Y9pdhC1p/logo.png">
<?php else: ?>
<?php echo e($slot); ?>

<?php endif; ?>
</a>
</td>
</tr>
<?php /**PATH G:\srv\laravel\IProyect\resources\views/vendor/mail/html/header.blade.php ENDPATH**/ ?>