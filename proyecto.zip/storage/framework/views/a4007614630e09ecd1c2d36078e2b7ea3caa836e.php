<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Mensaje nuevo</title>
</head>
<body>
    <p>Nuevo mensaje de: <?php echo e($mensaje['nombre']); ?> - <?php echo e($mensaje['correo']); ?></p>
    <p>Asunto: <strong><?php echo e($mensaje['asunto']); ?></strong> </p>
    <p><?php echo e($mensaje['mensaje']); ?></p>
</body>
</html>
<?php /**PATH G:\srv\laravel\IProyect\resources\views/email/formulario-contacto.blade.php ENDPATH**/ ?>