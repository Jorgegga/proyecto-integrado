@inject('playMusic', 'App\Models\Playlist')
<x-app-layout>
    <x-slot name="fonts">
    </x-slot>
    <x-slot name="styles">
        <link href="{{ asset('css/green-audio-player.css') }}" rel="stylesheet">
        <link rel="stylesheet" href="https://cdn.datatables.net/1.10.24/css/dataTables.bootstrap4.min.css">
        <style>
            .green-audio-player {
                background-color: #0c171d;
            }

            .dataTables_wrapper {
                color: white;
            }

        </style>
    </x-slot>
    <x-slot name="scriptsCDN">
        <script src="{{ asset('js/green-audio-player.js') }}" defer></script>
    </x-slot>
    <x-slot name="header">
        <h2 class="font-semibold text-xl text-white leading-tight">
            {{ __('Música') }}
        </h2>
    </x-slot>
    <x-slot name="cuerpo">
        <div class="py-12 animate__animated animate__fadeInDown">
            <div class="max-w-7xl mx-auto sm:px-6 lg:px-8 mb-4">
                <div class="overflow-hidden shadow-sm rounded pt-2" style="background-color:#212E36;">
                    <div class="p-6 border-b border-gray-200 text-center">
                        <h4 style="color: #EFF3F5">Toda nuestra base de datos de música</h4>
                        <p style="color: #C8CDD0">Aquí la encontrarás</p>
                    </div>
                </div>
            </div>
        </div>
        <section
            class="row justify-content-center mt-md-4 mb-md-4 mt-sm-4 mb-sm-4 animate__animated animate__fadeIn animate__slow">
            <!--<div class="col-10 pr-3">-->
            <div class="table-responsive">
                <table class="table table-striped table-dark" id="tabla">
                    <thead>
                        <tr>
                            <th scope="col">Nombre</th>
                            <th scope="col">Álbum</th>
                            <th scope="col">Autor</th>
                            <th scope="col">Género</th>
                            <th scope="col">Play</th>
                            @auth
                                <th scope="col">Añadir</th>
                            @endauth
                        </tr>
                    </thead>
                    <tbody>
                        @foreach ($musica as $item)
                            <tr>
                                <td>{{ $item->nombre }}</td>
                                <td>
                                    <a
                                        href="{{ route('verAlbum', ['album' => $item->album->id, 'nombre' => $item->album->nombre]) }}">{{ $item->album->nombre }}</a>
                                </td>
                                <td><a
                                        href="{{ route('verAutor', ['autor' => $item->autor->id, 'nombre' => $item->autor->nombre]) }}">{{ $item->autor->nombre }}</a>
                                </td>
                                <td>{{ ucfirst($item->genero->nombre) }}</td>
                                <!-- Los audios cargan correctamente en apache y al usar php artisan serve en modo incognito -->
                                <td>
                                    <div class="audioExample"><audio preload="none" id='{{ $item->id }}'
                                            onplay="parar(this.id)" onended="siguiente(this.id)">
                                            <source src="{{ asset($item->ruta) }}" type="audio/ogg">
                                            <source src="{{ asset($item->ruta) }}" type="audio/mp3">
                                            No lo soporta
                                        </audio></div>
                                </td>
                                @auth
                                    <td>
                                        @if ($playMusic->musicExist(Auth::user(), $item->id) == 0)
                                            <form method="POST"
                                                action="{{ route('playlists.store', ['user' => Auth::user()->id, 'music' => $item->id]) }}"
                                                id="anadirPlaylist{{ $item->id }}"
                                                onsubmit="submitForm(event, {{ $item->id }})">
                                                @csrf
                                                <button id="btn{{ $item->id }}" type="submit"
                                                    title="Añadir a tu playlist"><i class="fas fa-plus"></i></button>
                                            </form>
                                        @else
                                            <button type="submit" title="Ya esta en tu playlist" disabled><i
                                                    class="fas fa-plus"></i></button>
                                        @endif
                                    </td>
                                @endauth
                            </tr>
                        @endforeach
                    </tbody>
                </table>
            </div>

            <!--</div>-->
        </section>

    </x-slot>
    <x-slot name="script">
        <script>
            $(document).ready(function() {
                $('#tabla').DataTable();
            });

/*
            $(document).ready(function(){
                $('#tabla').DataTable({
                    "processing": true,
                    "serverSide": true,
                    "ajax":{
                        url:"{{ url('api/musics') }}",

                        dataType: 'json',
                        contentType: 'application/json; charset=utf-8',
                    },
                    "columns": [
                        {data: 'nombre', },
                        {data: 'album_id', },
                        {data: 'autor_id', },
                        {data: 'genero_id', },
                        {data: 'ruta',},
                        {data: 'añadir'}
                    ]
                });
            });*/

            document.addEventListener('DOMContentLoaded', function() {
                var audios = document.getElementsByClassName("audioExample");
                for (var i = 0; i < audios.length; i++) {
                    new GreenAudioPlayer(audios[i], {
                        selector: '.player',
                        stopOthersOnPlay: true,
                    });
                }

            });

            function parar(idEl) {
                var elementos = document.getElementsByTagName('audio');
                for (var i = 0; i < elementos.length; i++) {
                    try {
                        if (elementos[i].id == idEl) {
                            var playPromise = elementos[i].play();
                            //Es necesario para que no salte error
                            playPromise.then(_ => {

                            }).catch(error => {

                            });

                        } else {
                            elementos[i].pause();
                        }
                    } catch (e) {
                        console.log("Error " + e)
                    }
                }
            }

            function siguiente(id) {
                id = parseInt(id);
                var elementos = document.getElementsByTagName('audio');
                for (var i = 0; i < elementos.length; i++) {
                    if (elementos[i].id == id) {
                        try {
                            if (elementos[i + 1] != null) {
                                elementos[i + 1].play();
                            } else {
                                console.log("Fin de la lista");
                            }
                        } catch (e) {
                            console.log("Error " + e)
                        }
                    } else {
                        elementos[i].pause();
                    }
                }
            }

            function submitForm(event, id) {
                boton = "btn" + id;
                id = "#anadirPlaylist" + id;
                $.ajax({
                    type: $(id).attr('method'),
                    url: $(id).attr('action'),
                    data: $(id).serialize(),
                    success: function(data) {
                        console.log('Datos enviados !!!');
                        document.getElementById(boton).disabled = true;
                        document.getElementById(boton).title = "Ya esta en tu playlist";
                    }
                });
                event.preventDefault();
            }

        </script>
    </x-slot>
</x-app-layout>
