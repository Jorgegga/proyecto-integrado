require('./bootstrap');

require('alpinejs');